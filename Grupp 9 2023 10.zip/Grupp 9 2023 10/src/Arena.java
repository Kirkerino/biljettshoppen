public class Arena {
    private int Id;
    private int EventId;
    private String Plats;
    private String Adress;
    private String ArenaNamn;


    private String Kopare;
    private boolean Betald;
    private String Betalningsmetod;



    public void setArenaNamn(String ArenaNamn) {
        this.ArenaNamn=ArenaNamn;
    }
    public String getArenaNamn() {
        return this.ArenaNamn;
    }

    public void setAdress(String Adress) {
        this.Adress = Adress;
    }
    public String getAdress() {
        return this.Adress;
    }


} //end
