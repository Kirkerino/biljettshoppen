import javax.swing.*;

public class BiljettS {

    public static void main(String[] args) {







        /*
        * OM MAN VILL TESTA BETALNING
        *  Betalning direktbetalning = new Direktbetalning();
        direktbetalning.betala(100.0);  // Du bör se ett meddelande i konsolen

        // Skapa en instans av FakturaBetalning
        Betalning faktura = new Faktura();
        faktura.betala(200.0);  // Du bör se ett meddelande i konsolen
        * */




    }//end main
}
