

   public interface Betalning {
       void betala(double belopp);

    }

    /*
    public class Direktbetalning implements Betalning {
        @Override
        public boolean utforBetalning(double belopp) {
            // Implementera logik för direktbetalning här...

         return true; // Exempel på att betalningen lyckades.
        }
    }


    class Faktura implements Betalning {
        @Override
        public boolean utforBetalning(double belopp) {
            // Implementera logik för att skapa en faktura här...
            return true; // Exempel på att skapande av faktura lyckades.
        }
    }
    */
