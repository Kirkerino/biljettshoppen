public abstract class Plats {
    private boolean platsUpptagen;
    private int platsnummer;

    public Plats(int platsnummer) {
        this.platsnummer = platsnummer;
        this.platsUpptagen = false;
    }

    public void boka() {
        platsUpptagen = true;
    }

    public void avboka() {
        platsUpptagen = false;
    }

    public boolean platsUpptagen() {
        return platsUpptagen;
    }

    // Andra gemensamma metoder för alla platser...
}

public class Bank extends Plats {
    public Bank(int platsnummer) {
        super(platsnummer);
    }
    // Specifika metoder för Bank...
}

public class Staplats extends Plats {
    public Staplats(int platsnummer) {
        super(platsnummer);
    }
    // Specifika metoder för Staplats...
}

public class Fallstol extends Plats {
    public Fallstol(int platsnummer) {
        super(platsnummer);
    }
    // Specifika metoder för Fallstol...
}

public class Handikappanpassad extends Plats {
    public Handikappanpassad(int platsnummer) {
        super(platsnummer);
    }
    // Specifika metoder för Handikappanpassad...
}

